package main;

public enum GameType
{
	PvP,
	PvC,
	CvC
}
